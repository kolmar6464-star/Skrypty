#requires -Version 5.1
<# Uruchamiaj ręcznie na testowym Windows. Test tworzy tylko własne, losowo nazwane wpisy
HKCU i pliki tymczasowe, po czym usuwa je w finally. Nie uruchamia instalacji sterowników. #>
$ErrorActionPreference='Stop'
if($env:OS -ne 'Windows_NT'){throw 'Ten test wymaga Windows; nie zaliczono integracji.'}
$path=Join-Path $PSScriptRoot '../ASUS-ROG-Manager.ps1'
$t=$null;$e=$null;$ast=[Management.Automation.Language.Parser]::ParseFile((Resolve-Path $path),[ref]$t,[ref]$e)
if($e.Count){throw ($e | Out-String)}
foreach($node in $ast.EndBlock.Statements | Where-Object {$_ -is [Management.Automation.Language.FunctionDefinitionAst]}){. ([scriptblock]::Create($node.Extent.Text))}
$id='ROG-Test-'+[guid]::NewGuid().ToString('N')
$temp=Join-Path $env:TEMP $id
$Script:SettingsDir=Join-Path $temp 'settings';$Script:LogPath=Join-Path $temp 'test.log';$Script:Version='test';$Script:Headless=$true
New-Item -ItemType Directory -Path $temp,$Script:SettingsDir -Force | Out-Null
$base=[Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::CurrentUser,[Microsoft.Win32.RegistryView]::Default)
$run='Software\Microsoft\Windows\CurrentVersion\Run'
$once='Software\Microsoft\Windows\CurrentVersion\RunOnce'
$approval='Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run'
$folderApproval='Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\StartupFolder'
$disabled='Software\ASUS_ROG_Manager\DisabledRunOnce'
function Assert-State([bool]$Condition,[string]$Message){if(-not $Condition){throw $Message};Write-Host ('PASS '+$Message)}
try {
    foreach($keyPath in @($run,$once)){
        $key=$base.CreateSubKey($keyPath)
        try{$key.SetValue($id,'%SystemRoot%\System32\cmd.exe /c exit 0',[Microsoft.Win32.RegistryValueKind]::ExpandString)}finally{$key.Dispose()}
    }
    $entry=[pscustomobject]@{Name=$id;Type='Run';Scope='CurrentUser';Enabled=$true;Command='test';Hive='CurrentUser';View='Default';Key=$run;Approval=$approval;Id=$id;CanToggle=$true}
    Set-StartupEntry $entry $false
    $key=$base.OpenSubKey($approval)
    try{Assert-State (-not (Get-ApprovalEnabled $key.GetValue($id))) 'HKCU Run: wyłączenie'}finally{$key.Dispose()}
    $entry.Enabled=$false;Set-StartupEntry $entry $true
    $key=$base.OpenSubKey($approval)
    try{Assert-State (Get-ApprovalEnabled $key.GetValue($id)) 'HKCU Run: ponowne włączenie'}finally{$key.Dispose()}
    $entry.Type='RunOnce';$entry.Key=$once;$entry.Enabled=$true
    Set-StartupEntry $entry $false
    $key=$base.OpenSubKey($disabled)
    try{Assert-State ($id -in $key.GetValueNames()) 'RunOnce: kopia wpisu wyłączonego'}finally{$key.Dispose()}
    $entry.Enabled=$false;Set-StartupEntry $entry $true
    $key=$base.OpenSubKey($once)
    try{Assert-State ($key.GetValueKind($id) -eq [Microsoft.Win32.RegistryValueKind]::ExpandString) 'RunOnce: zachowany typ ExpandString'}finally{$key.Dispose()}
    $folder=Join-Path $temp 'startup';New-Item -Path $folder -ItemType Directory | Out-Null
    $file=Join-Path $folder ($id+'.cmd');Set-Content -LiteralPath $file -Value '@exit /b 0'
    $entry=[pscustomobject]@{Name=($id+'.cmd');Type='Folder';Scope='Startup';Enabled=$true;Command=$file;Id=$file;Folder=$folder;CanToggle=$true}
    Set-StartupEntry $entry $false
    $moved=Join-Path (Join-Path $folder 'ASUS-Disabled') ($id+'.cmd')
    Assert-State ((Test-Path -LiteralPath $moved) -and -not (Test-Path -LiteralPath $file)) 'Folder: wyłączenie bez kasowania pliku'
    $entry.Enabled=$false;$entry.Id=$moved;Set-StartupEntry $entry $true
    Assert-State (Test-Path -LiteralPath $file) 'Folder: przywrócenie pliku'
    Assert-State (@(Get-ChildItem (Join-Path $Script:SettingsDir 'Autostart-backup') -Filter *.json).Count -eq 6) 'Kopia każdej zmiany'
    Write-Host 'Integracja HKCU Run, RunOnce, Folder: zaliczona. Usługi, zadania, MSIX, GUI i NTLite wymagają osobnych prób.'
} finally {
    foreach($keyPath in @($run,$once,$approval,$disabled,$folderApproval)){
        $key=$base.OpenSubKey($keyPath,$true)
        if($key){try{$key.DeleteValue($id,$false);$key.DeleteValue(($id+'.cmd'),$false)}finally{$key.Dispose()}}
    }
    $base.Dispose()
    Remove-Item -LiteralPath $temp -Recurse -Force -ErrorAction SilentlyContinue
}
