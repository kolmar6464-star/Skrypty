﻿#requires -Version 5.1
# Testy bez zmian w Windows i bez wykonywania startu aplikacji.
$ErrorActionPreference='Stop'
$scriptPath=Join-Path $PSScriptRoot '../ASUS-ROG-Manager.ps1'
$tokens=$null;$errors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile((Resolve-Path $scriptPath),[ref]$tokens,[ref]$errors)
if($errors.Count){throw ($errors | Out-String)}
$Script:Passed=0
function Assert([bool]$Condition,[string]$Message){if(-not $Condition){throw $Message};$Script:Passed++;Write-Host ('PASS '+$Message)}
function Load-Functions($Tree){
    foreach($node in $Tree.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst]},$false)){
        # Only top-level definitions; nested worker functions are loaded separately.
        if($node.Parent -is [Management.Automation.Language.NamedBlockAst]){. ([scriptblock]::Create($node.Extent.Text))}
    }
}
# Dot-source definitions into this test scope, not the application's top-level code.
foreach($node in $ast.EndBlock.Statements | Where-Object {$_ -is [Management.Automation.Language.FunctionDefinitionAst]}){. ([scriptblock]::Create($node.Extent.Text))}
Assert ($errors.Count -eq 0) 'Parser głównego PS1'
$workers=@{}
foreach($name in @('Driver','Asus')){
    $assignment=$ast.EndBlock.Statements | Where-Object {$_ -is [Management.Automation.Language.AssignmentStatementAst] -and $_.Left.Extent.Text -eq ('$Script:'+ $name+'WorkerB64')}
    $value=$assignment.Right.Expression.Value
    $code=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String(($value -replace '\s','')))
    $t=$null;$e=$null;$tree=[Management.Automation.Language.Parser]::ParseInput($code,[ref]$t,[ref]$e)
    Assert ($e.Count -eq 0) ('Parser modułu '+$name)
    $workers[$name]=[scriptblock]::Create($code)
    if($name -eq 'Asus'){
        foreach($node in $tree.EndBlock.Statements | Where-Object {$_ -is [Management.Automation.Language.FunctionDefinitionAst]}){. ([scriptblock]::Create($node.Extent.Text))}
    }
}
Assert (Test-ProtectedStartupService 'C:\Windows\System32\svchost.exe -k netsvcs') 'Usługa Windows chroniona'
Assert (Test-ProtectedStartupService '\SystemRoot\System32\driver.sys') 'Sterownik SystemRoot chroniony'
Assert (Test-ProtectedStartupService '') 'Nieznana ścieżka usługi chroniona'
Assert (Get-ApprovalEnabled $null) 'Brak StartupApproved oznacza włączenie'
Assert (Get-ApprovalEnabled ([byte[]]@(2,0,0,0))) 'Stan autostartu 2 włączony'
Assert (Get-ApprovalEnabled ([byte[]]@(6,0,0,0))) 'Stan autostartu 6 włączony'
Assert (-not (Get-ApprovalEnabled ([byte[]]@(3,0,0,0)))) 'Stan autostartu 3 wyłączony'
Assert (-not (Get-ApprovalEnabled ([byte[]]@(7,0,0,0)))) 'Stan autostartu 7 wyłączony'
Assert (Test-SafeUrl 'https://dlcdnets.asus.com/pub/ASUS/DRV_WLAN_Intel_Win11.zip') 'Dozwolony oficjalny HTTPS ASUS'
Assert (-not (Test-SafeUrl 'http://dlcdnets.asus.com/driver.zip')) 'Odrzucenie HTTP'
Assert (-not (Test-SafeUrl 'https://dlcdnets.asus.com.evil.example/driver.zip')) 'Odrzucenie fałszywego hosta'
Assert (-not (Test-SafeUrl 'https://dlcdnets.asus.com/pub/BIOS_update.zip')) 'Odrzucenie BIOS'
Assert (-not (Test-SafeUrl 'https://dlcdnets.asus.com/pub/firmware.zip')) 'Odrzucenie firmware'
Assert (-not (Test-OsUrl 'https://dlcdnets.asus.com/DRV_Win10.zip' 'Windows 11 64-bit')) 'Nie dobiera pakietu tylko Win10 do Win11'
Assert ((Get-Family 'https://dlcdnets.asus.com/DRV_Bluetooth_Intel_Win11.zip') -eq 'bluetooth-intel') 'Rodzina Bluetooth Intel'
Assert (-not (Test-FamilyCompatible 'wlan-intel' ([pscustomobject]@{Intel=$false}))) 'Odrzucenie nieobecnego producenta'
Assert ((Get-FamilyPriority 'chipset-intel') -lt (Get-FamilyPriority 'graphics-nvidia')) 'Chipset przed grafiką'
$threw=$false;try{Check-Code 1603 'instalator'}catch{$threw=$true}
Assert $threw 'Nieudana instalacja nie jest sukcesem'
Check-Code 3010 'instalator'
Assert $true 'Kod 3010 akceptowany jako wymagający restartu'
$Script:Headless=$true;$Script:ProgramName='Test';$Script:Version='test';$Script:LogPath=Join-Path ([IO.Path]::GetTempPath()) ('rog-test-'+[guid]::NewGuid()+'.log')
try {
    Assert (-not (Ask-YesNo 'test')) 'SYSTEM nie otwiera pytania ani nie udziela zgody'
    $entry=[pscustomobject]@{Name='Protected';CanToggle=$false;Enabled=$true;Type='Zadanie';Scope='Komputer'}
    $threw=$false;try{Set-StartupEntry $entry $false}catch{$threw=$true}
    Assert $threw 'Odmowa zmiany chronionego autostartu'
    $entry=[pscustomobject]@{Name='Already enabled';CanToggle=$true;Enabled=$true;Type='Run';Scope='CurrentUser'}
    Set-StartupEntry $entry $true
    Assert $true 'Ponowne włączenie aktywnego wpisu nie zmienia systemu'
    # Simulacja Windows Update: brak sprzętu Bluetooth nie generuje fikcyjnego braku.
    function Get-CimInstance {param($ClassName) [pscustomobject]@{Name='Device';Present=$true;ConfigManagerErrorCode=0;PNPClass='System';PNPDeviceID='PCI\VEN_1234';HardwareID=@('PCI\VEN_1234');CompatibleID=@()}}
    function Start-Sleep {param($Milliseconds)}
    function New-Object {
        param([string]$ComObject,[string]$TypeName)
        if($ComObject -eq 'Microsoft.Update.ServiceManager') {throw 'Optional service not available'}
        if($ComObject -eq 'Microsoft.Update.Session'){
            $searcher=[pscustomobject]@{Online=$false}
            $searcher | Add-Member ScriptMethod Search {param($Query) if($Script:FailSearch){throw 'Simulated network error'}; [pscustomobject]@{Updates=[pscustomobject]@{Count=0}}}
            $session=[pscustomobject]@{ClientApplicationID='';Searcher=$searcher}
            $session | Add-Member ScriptMethod CreateUpdateSearcher {$this.Searcher}
            return $session
        }
        throw ('Unexpected New-Object: '+$ComObject+' / '+$TypeName)
    }
    $oldRoot=$env:SystemRoot;$env:SystemRoot=[IO.Path]::GetTempPath()
    try {
        $Script:FailSearch=$false
        $events=@(& $workers.Driver -Mode Check)
        $final=@($events | Where-Object Kind -eq 'Final')
        Assert ($final.Count -eq 1 -and $final[0].MissingCount -eq 0 -and -not $final[0].BluetoothMissing) 'WU Check: brak fikcyjnego Bluetooth, wynik końcowy'
        $Script:FailSearch=$true
        $events=@(& $workers.Driver -Mode Check)
        Assert (@($events | Where-Object { $_.Kind -eq 'Final' -and $_.Level -eq 'ERROR' }).Count -eq 1) 'Błąd sieci WU zwraca ERROR'
    } finally {$env:SystemRoot=$oldRoot;Remove-Item Function:New-Object;Remove-Item Function:Get-CimInstance;Remove-Item Function:Start-Sleep}
    function Get-WinGetCommand {return 'mock-winget'}
    function Invoke-WinGetRaw {param([string[]]$Arguments) if($Arguments[0] -eq 'source'){return [pscustomobject]@{Output=@();ExitCode=0}};return [pscustomobject]@{Output=@('Simulated source failure');ExitCode=123}}
    function Set-Status {param($Text,$Level) $Script:ObservedLevel=$Level}
    $Script:ActionRunning=$false;$Script:ObservedLevel=''
    Check-ProgramUpdates
    Assert ($Script:ObservedLevel -eq 'ERROR') 'Błąd WinGet nie jest zgłaszany jako brak aktualizacji'
    Remove-Item Function:Get-WinGetCommand;Remove-Item Function:Invoke-WinGetRaw;Remove-Item Function:Set-Status
    $temp=Join-Path ([IO.Path]::GetTempPath()) ('rog-payload-'+[guid]::NewGuid())
    New-Item $temp -ItemType Directory | Out-Null
    try {
        $fake=Join-Path $temp 'setup.exe';Set-Content -LiteralPath $fake -Value 'Not executable'
        $result=Install-Payload $fake (Join-Path $temp 'extract')
        Assert ($result -match '^Pakiet pobrany') 'Nieznany instalator EXE nie jest uruchamiany z domyślnym -s'
    } finally {Remove-Item -LiteralPath $temp -Recurse -Force}
} finally {Remove-Item -LiteralPath $Script:LogPath -ErrorAction SilentlyContinue}
Write-Host ('WYNIK: '+$Script:Passed+' zaliczonych testów; integracja Windows/NTLite nie była wykonywana.')
