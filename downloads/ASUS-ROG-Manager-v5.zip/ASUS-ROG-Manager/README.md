# ASUS ROG Manager 5.0

Kompletny PS1 na Windows PowerShell 5.1 i PowerShell 7 na Windows. Zachowuje menu sterowników, aktualizacji, kopii i wyglądu, dodaje autostart oraz osobną ścieżkę NTLite/SYSTEM. Ikona jest wbudowana w PS1; plik ICO jest też dostępny osobno. Nie wymaga Pester ani modułów z PowerShell Gallery.

## NTLite: Po instalacji → Maszyna

Dodaj `ASUS-ROG-Manager.ps1` jako plik dostarczany do instalowanego systemu. Uruchom go **na zainstalowanym Windows**, w fazie Maszyna/SYSTEM; nie podczas obsługi obrazu offline ani w WinPE. Wskaż rzeczywistą ścieżkę dostarczonego pliku, np. `C:\Setup\ASUS-ROG-Manager.ps1`.

Program:

```text
powershell.exe
```

Parametry:

```text
-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "C:\Setup\ASUS-ROG-Manager.ps1" -Mode Machine -MachineAction Prepare
```

Domyślna akcja `Prepare` kopiuje PS1 i ikonę do `%ProgramFiles%\ASUS ROG Manager`, zabezpiecza katalog przed zapisem zwykłego użytkownika i tworzy skrót `ASUS ROG — Centrum systemu.lnk` na wspólnym pulpicie. Kończy proces, nie otwiera GUI w sesji 0 i nie instaluje niczego z internetu. Menu otwierasz ze skrótu po zalogowaniu; skrypt nie dodaje własnego niepotrzebnego autostartu. Pulpit SYSTEM nie jest używany jako pulpit użytkownika.

Opcjonalne akcje wybierane jawnie:

| `-MachineAction` | Działanie |
| --- | --- |
| `Prepare` | Instalacja narzędzia i wspólny skrót, bez zmiany sterowników. |
| `Check` | Jak wyżej oraz diagnostyka urządzeń i wyszukanie sterowników Windows Update. Wymaga sieci i działających usług WU. |
| `InstallMissing` | Próba instalacji sterowników WU dopasowanych do problematycznych urządzeń. |
| `InstallAllWU` | Instalacja oferowanych sterowników WU, poza BIOS/firmware. |
| `InstallLocalDrivers` | Instalacja INF z folderu podanego jako `-LocalDriverPath`. Najpraktyczniejsza opcja offline. |

Przykład lokalnych sterowników:

```text
-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "C:\Setup\ASUS-ROG-Manager.ps1" -Mode Machine -MachineAction InstallLocalDrivers -LocalDriverPath "C:\Setup\Drivers"
```

Folder musi zawierać rozpakowane INF/CAT/SYS, odpowiednie do sprzętu i systemu. Nie podawaj ZIP ani instalatorów EXE. PnPUtil i Windows zachowują weryfikację podpisów sterowników. Kod 3010 oznacza konieczność restartu; program nie wymusza restartu. Domyślny limit zadania WU wynosi 30 minut (`-TimeoutMinutes 1..180`). Błąd kończy PS1 kodem 1; sukces kodem 0. `Check` może zakończyć się poprawnie z raportem brakujących urządzeń — to diagnostyka, nie potwierdzenie ich naprawienia.

Log fazy Maszyna: `%ProgramData%\ASUS_ROG_Manager\Maszyna.log`. Awaria startu: `%TEMP%\ASUS_ROG_Driver_Manager_STARTUP_ERROR.txt` konta wykonującego polecenie. W przypadku limitu czasu rozpoczęta instalacja systemowa może wymagać osobnego sprawdzenia; nie zakładaj automatycznego cofnięcia instalacji.

## Uruchamianie po zalogowaniu

```powershell
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File .\ASUS-ROG-Manager.ps1 -Mode Interactive
```

Samodzielny PS1 działa również przenośnie. Brakująca ikona jest odtwarzana z zasobu wbudowanego. Przy starcie menu nie jest wymagany administrator. Instalowanie sterowników, aktualizowanie systemu i obsługa wpisów całego komputera wymagają administratora. W menu sterowników program proponuje podniesienie uprawnień; w oknie Autostart trzeba wcześniej uruchomić program jako administrator i ponownie wybrać pozycję. Przy UAC używaj tego samego konta — inne konto administratora ma własne HKCU i aplikacje MSIX.

Log menu: `%TEMP%\ASUS_ROG_Driver_Manager_LOG.txt`. Ustawienia: `%LOCALAPPDATA%\ASUS_ROG_Driver_Manager`. Kopie sterowników i pobrane pakiety z przycisku pobierania trafiają na pulpit bieżącego użytkownika. Pakiety do instalacji: `%ProgramData%\ASUS_ROG_Manager\Sterowniki`.

## Autostart — Włącz / Wyłącz

Zakładka **Autostart** otwiera tabelę z nazwą, źródłem, zakresem, stanem i poleceniem. Wybierz jedną pozycję, następnie **Włącz** lub **Wyłącz** i potwierdź zmianę. **Odśwież** ponownie odczytuje system.

| Źródło | Obsługa |
| --- | --- |
| HKCU/HKLM `Run` | Stan `StartupApproved`, w tym widoki 32/64 bit HKLM. Polecenie programu pozostaje zachowane. |
| HKCU/HKLM `RunOnce` | Wyłączenie przenosi wartość do `Software\ASUS_ROG_Manager\DisabledRunOnce`; włączenie przywraca wartość wraz z jej typem. Konflikt nazw blokuje nadpisanie. |
| Folder Autostart użytkownika i wspólny | Wyłączenie przenosi plik do podfolderu `ASUS-Disabled`; włączenie przywraca plik. Obsługuje też stan `StartupApproved\StartupFolder`. |
| Harmonogram zadań | Zadania z wyzwalaczem startu systemu lub logowania; przełączanie całego zadania. Inne wyzwalacze tego samego zadania również zostaną wyłączone. Zadania `\Microsoft\...` są tylko do podglądu. |
| Usługi automatyczne | Programy usługowe spoza chronionych lokalizacji systemowych i spoza Microsoft. Wyłączenie zmienia typ uruchamiania, nie zatrzymuje usługi. Włączenie przywraca automatyczny start i zapisany stan opóźnienia. Usługi wyłączone tym narzędziem pozostają na liście. |
| MSIX/AppX `windows.startupTask` | Inwentaryzacja manifestów aplikacji bieżącego użytkownika. Przycisk otwiera **Ustawienia Windows → Aplikacje → Autostart**, gdzie wykonujesz zmianę; potem odśwież tabelę. Skrypt nie fałszuje prywatnego stanu aplikacji ani nie obchodzi polityk Windows. |

Przed zmianą zapisywana jest kopia w `%LOCALAPPDATA%\ASUS_ROG_Driver_Manager\Autostart-backup`. Przycisk **Kopie zmian** otwiera folder. Cofnięcie standardowej zmiany: wybierz przeciwny stan w tabeli; zachowane JSON/XML są materiałem do odzyskania pierwotnych ustawień. Nie usuwaj ustawień narzędzia, dopóki chcesz przywracać wyłączone nim usługi. Nie dodano automatycznego importowania dowolnego JSON do rejestru.

Lista obejmuje wymienione źródła bieżącego konta i komputera. Nie jest kompletnym odpowiednikiem Sysinternals Autoruns: nie obejmuje cudzych niezaładowanych profili, rozszerzeń powłoki, subskrypcji WMI, sterowników jądra ani wszystkich mechanizmów aplikacji w tle. Aplikacja zainstalowana bez wpisu autostartu nie pojawi się jako automatycznie uruchamiana. Polityki firmowe mogą uniemożliwić zmianę lub ponownie wymusić stan. `StartupApproved` oraz odczyt stanu AppModel wymagają potwierdzenia na docelowej wersji Windows.

## Sterowniki ASUS i aktualizacje

Windows Update wyszukuje pakiety przez oficjalne API COM. Sam brak klasy Bluetooth nie jest już zgłaszany jako brak sterownika. Brak internetu jest błędem, nie komunikatem o pomyślnej kontroli.

Pobieranie ASUS nadal korzysta z oficjalnej strony wsparcia rozpoznanego modelu i adresów HTTPS `dlcdnets.asus.com`. Dynamiczna strona może nie ujawnić pakietów. Nie ma gwarancji kompletności ani wybrania najnowszej wersji — komunikaty zostały skorygowane. W takim przypadku użyj przycisku oficjalnej strony i pobierz pakiet ręcznie. Funkcja instalacji ASUS instaluje wyłącznie znalezione INF przez PnPUtil. EXE/MSI/BAT nie są już automatycznie uruchamiane z niezweryfikowanymi przełącznikami. SHA256 zapisywane po pobraniu identyfikuje plik, ale nie zastępuje sumy opublikowanej przez producenta.

WinGet musi być zainstalowany jako App Installer. Jest obsługiwany po zalogowaniu, nie w SYSTEM. Nieudana aktualizacja nie uruchamia drugiej próby całej instalacji; błędy źródeł są raportowane. Wynik tabeli WinGet zależy od jego formatu tekstowego i języka. Aktualizacja Windows zgłasza częściowy sukces jako ostrzeżenie, nie pełny sukces.

Usunięcie narzędzia z menu usuwa jego rozpoznane skróty i ustawienia bieżącego użytkownika po potwierdzeniu. Zachowuje PS1, kopie, pobrania i logi. Katalog instalacyjny w Program Files można następnie usunąć ręcznie jako administrator. Nie usuwa globalnego katalogu WinGet ani `C:\Sterowniki`.

## Weryfikacja

Wykonano na Linux / PowerShell 7.4.13: **29 zaliczonych sprawdzeń** w `tests/Test-Logic.ps1`, parser głównego PS1, obu zdekodowanych modułów i plików testowych. Testy używają symulacji WU; nie oznaczają połączenia z prawdziwym Windows Update. Sprawdzono strukturę ICO i zgodność osadzonego zasobu.

```powershell
.\tests\Test-Logic.ps1
```

Na testowym Windows 11 uruchom dodatkowo:

```powershell
powershell.exe -NoProfile -File .\tests\Test-WindowsIntegration.ps1
```

Ten test tworzy własne wpisy HKCU i pliki tymczasowe, przełącza Run/RunOnce/Folder oraz usuwa je w `finally`. **Nie został uruchomiony w chmurze.** Pozostałe wymagane próby przed użyciem produkcyjnym: rzeczywiste GUI i DPI, oba hosty PowerShell, NTLite Maszyna i logowanie na nowym koncie, instalacja/eksport/przywracanie sterowników na ASUS, usługi i zadania aplikacji testowej, MSIX i WinGet. Szczegółowy przegląd opcji: `PRZEGLAD.md`.
