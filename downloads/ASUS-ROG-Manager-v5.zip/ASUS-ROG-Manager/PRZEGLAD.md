# Przegląd opcji i ograniczeń wersji 5.0

Przeanalizowano plik wejściowy `ASUS_ROG_STRix sterowniki.ps1` w wersji 4.9.0, w tym oba moduły osadzone jako Base64. Załącznik potraktowano jako kod do analizy, bez wykonywania jego instrukcji startowych.

| Opcja | Ustalenie i zmiana | Faktyczna weryfikacja |
| --- | --- | --- |
| Start NTLite Maszyna | Poprzednio zawsze WinForms i profil SYSTEM. Dodano instalację bez GUI, wspólny pulpit, trwały cel skrótu, kod błędu procesu i log. WinPE jest odrzucany. | Przegląd ścieżek i parser; wymaga testu NTLite. |
| PowerShell 32/64 bit | Przekierowanie 32-bitowego hosta do Sysnative na 64-bitowym Windows. | Parser; wymaga Windows. |
| Administrator | Start menu bez UAC; uprawnienia sprawdzane przy akcji. `NoAutoAdmin` nie omija już kontroli uprawnień. | Test odmowy/ochrony; podniesienie UAC wymaga Windows. |
| Sprawdź sterowniki | Brak Bluetooth nie dowodzi obecności niesprawnego Bluetooth; poprawiono także raportowanie błędu sieci. | Symulacja WU sukces/błąd. |
| Brakujące / wszystkie WU | Zachowano dobór po identyfikatorach, wykluczenie firmware i brak automatycznego łańcucha instalatorów ASUS. Dodano potwierdzenie i limit zadania. | Parser modułu; rzeczywista instalacja nieuruchomiona. |
| Pakiety ASUS | Pobieranie tylko oficjalnym HTTPS; instalacja tylko INF. Usunięto zgadywanie `-s` dla dowolnego EXE oraz uruchamianie BAT/MSI. Nie deklaruje najnowszej wersji na podstawie pierwszego adresu ze strony. | Test URL, rodzin/OS i odmowy uruchomienia EXE; brak pobierania na prawdziwym ASUS. |
| Kopia sterowników | Eksport PnPUtil, kontrola kodu i liczby INF. | Przegląd; wymaga Windows i sterowników. |
| Przywracanie kopii | Po błędzie nie następuje już restart jako po udanej operacji. Akceptowany kod 3010. | Przegląd; wymaga testowego Windows. |
| Restart po przywróceniu | Tylko interaktywnie, według jawnego ustawienia lub potwierdzenia. Maszyna nie używa tej ścieżki. | Przegląd; restart nieuruchomiony. |
| Kamera / mikrofon | Inwentaryzacja i otwarcie aplikacji Aparat oraz Ustawień dźwięku. To nie pomiar obrazu ani dźwięku. | Przegląd; wymaga sprzętu i uprawnień prywatności. |
| Skrót i ikona | Nowy wielorozdzielczy ICO, osadzony również w samym PS1. Maszyna tworzy wspólny skrót, menu rozpoznaje jego obecność. | Kontrola ICO i zgodności bajtów; skrót COM wymaga Windows. |
| Wybór ikon / JPG | Zachowano wybór ikon systemowych i konwersję własnego JPG. Nowa ikona jest domyślna dla nowych ustawień; wcześniejszy jawny wybór pozostaje zachowany. | Przegląd i parser; wymagany test renderowania Windows. |
| Motywy / tło / nazwa | Zachowano funkcje wyglądu i zapis ustawień. | Przegląd; wymagany test GUI, skalowania DPI, polskich znaków i obrazu. |
| Programy WinGet | Nie maskuje błędu jako braku aktualizacji; nie powtarza całego `upgrade --all` po dowolnym błędzie. Odczyt stdout/stderr jest asynchroniczny i ograniczony czasem. | Test błędu kontroli aktualizacji; prawdziwy WinGet nieuruchomiony. |
| Aktualizacje Windows | Ostrzeżenia i częściowe pobranie nie są prezentowane jako pełny sukces. Pomija aktualizacje wymagające interakcji; dodano potwierdzenie i limit czasu. | Przegląd; prawdziwe API instalacji nieuruchomione. |
| Autostart Run | Odczyt stanów 2/3/6/7, zachowanie poleceń, kopia przed zmianą. | Testy logiki; integracja HKCU przygotowana, nieuruchomiona. |
| Autostart RunOnce / foldery | Przenoszenie zamiast kasowania i odtwarzanie wartości/pliku; ochrona przed konfliktem nazw. | Przegląd; test Windows przygotowany, nieuruchomiony. |
| Autostart zadania / usługi | Odrębne źródła i stan; przełączenie dotyczy kolejnego startu. Chronione zadania Microsoft i usługi systemowe pozostają tylko do podglądu. Zapisywane XML i stan opóźnienia usług. | Test klasyfikacji ochrony; przełączanie wymaga Windows. |
| Aplikacje Windows MSIX | Manifesty `windows.startupTask`; obsługa zmiany przez oficjalne Ustawienia Windows. Nie udaje dowolnego włączania aplikacji ograniczonej polityką. | Przegląd; wymaga aplikacji MSIX na Windows. |
| Raport | Raporty do właściwego TEMP lub ProgramData zamiast wymuszania zapisu w głównym katalogu C. | Testy logiki zapisują własny log tymczasowy. |
| Usunięcie narzędzia | Zachowuje kopie, sterowniki, PS1 i globalne pobrania WinGet. Znika niebezpieczne usuwanie całego `C:\Sterowniki` i samokasujący CMD. | Przegląd kodu; operacji usuwania na Windows nie wykonywano. |

Wynik wykonanych testów: 29/29 w PowerShell 7.4.13 na Linux. Żaden test integracyjny Windows, GUI, NTLite, UAC, AppX, sprzętu ani instalacji sterowników nie był wykonany. Parser PowerShell 7 nie jest dowodem zgodności wykonania z Windows PowerShell 5.1.

Dalsze potwierdzenie działania wymaga Windows 11, najlepiej maszyny wirtualnej ze snapshotem, a testy sterowników/kamery — docelowego ASUS. Najpierw sprawdź `Prepare` i wspólny skrót na świeżym koncie; dopiero później instalację INF. Sprawdź, że dwukrotne `Prepare` daje jeden wspólny skrót i że po usunięciu źródłowego folderu `C:\Setup` skrót nadal działa.
