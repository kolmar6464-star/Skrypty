package pl.routercontrol.rtac1200gp;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.RouteInfo;

import java.net.Inet4Address;
import java.net.InetAddress;

/** Odczytuje brame domyslna Wi-Fi; nie identyfikuje producenta urzadzenia. */
public final class WifiGatewayDiscovery {
    private WifiGatewayDiscovery() { }

    public static String detect(Context context) {
        ConnectivityManager manager = (ConnectivityManager)
                context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (manager == null) return null;
        Network active = manager.getActiveNetwork();
        if (active == null) return null;
        NetworkCapabilities capabilities = manager.getNetworkCapabilities(active);
        if (capabilities == null
                || !capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                || capabilities.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) {
            return null;
        }
        LinkProperties links = manager.getLinkProperties(active);
        if (links == null) return null;
        for (RouteInfo route : links.getRoutes()) {
            InetAddress gateway = route.getGateway();
            if (route.isDefaultRoute() && gateway instanceof Inet4Address) {
                String value = gateway.getHostAddress();
                if (AddressPolicy.isPrivateIpv4(value)) return value;
            }
        }
        return null;
    }
}
