package pl.routercontrol.rtac1200gp;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Arrays;

/** Auto-IP z Wi-Fi, reczne IP na zyczenie, dane uwierzytelnienia jednorazowe. */
public final class MainActivity extends Activity {
    private EditText loginInput;
    private EditText passwordInput;
    private EditText addressInput;
    private TextView addressStatus;
    private TextView status;
    private LinearLayout manualPanel;
    private String currentRouterIp;
    private AddressChoice.Source selectedSource;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        getWindow().setStatusBarColor(Style.BG);
        getWindow().setNavigationBarColor(Style.BG);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Style.BG);
        LinearLayout root = Style.column(this);
        root.setPadding(Style.dp(this, 24), Style.dp(this, 30),
                Style.dp(this, 24), Style.dp(this, 28));
        scroll.addView(root);

        TextView title = Style.label(this, "ASUS CONTROL PL", 27, true);
        title.setTextColor(Style.RED);
        root.addView(title);
        TextView model = Style.label(this, "RT-AC1200G+ • automatyczny adres routera", 15, false);
        model.setTextColor(Style.MUTED);
        root.addView(model);

        addressStatus = Style.label(this, "Sprawdzanie adresu routera…", 14, false);
        addressStatus.setTextColor(Style.MUTED);
        root.addView(addressStatus);

        Button manual = Style.button(this, "WPISZ ADRES ROUTERA RĘCZNIE");
        manual.setOnClickListener(view -> {
            manualPanel.setVisibility(manualPanel.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
            addressInput.setText(currentRouterIp);
        });
        root.addView(manual);

        manualPanel = Style.column(this);
        manualPanel.setVisibility(View.GONE);
        root.addView(manualPanel);
        manualPanel.addView(Style.label(this, "Adres IPv4 routera, np. 192.168.2.1", 14, true));
        addressInput = Style.input(this, "192.168.2.1", RouterDefaults.IP);
        addressInput.setInputType(InputType.TYPE_CLASS_PHONE);
        manualPanel.addView(addressInput);
        Button save = Style.button(this, "ZAPISZ ADRES");
        save.setOnClickListener(view -> saveManualAddress());
        manualPanel.addView(save);

        Button detect = Style.button(this, "WYKRYJ ADRES Z WI-FI PONOWNIE");
        detect.setOnClickListener(view -> refreshAddress());
        root.addView(detect);

        root.addView(Style.label(this, "Login administratora routera", 15, true));
        loginInput = Style.input(this, "Login ASUS", "");
        loginInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        loginInput.setAutofillHints(View.AUTOFILL_HINT_USERNAME);
        root.addView(loginInput);

        root.addView(Style.label(this, "Hasło administratora routera", 15, true));
        passwordInput = Style.input(this, "Hasło ASUS", "");
        passwordInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        passwordInput.setAutofillHints(View.AUTOFILL_HINT_PASSWORD);
        root.addView(passwordInput);

        Button connect = Style.button(this, "POŁĄCZ Z ROUTEREM");
        connect.setOnClickListener(view -> connect());
        root.addView(connect);

        status = Style.label(this,
                "Aplikacja wykrywa bramę Wi-Fi, ale nie może automatycznie potwierdzić, " +
                "że to ASUS. Login i hasło nie są zapisywane.", 14, false);
        status.setTextColor(Style.MUTED);
        root.addView(status);

        Button vpn = Style.button(this, "USTAWIENIA VPN — DOSTĘP SPOZA DOMU");
        vpn.setOnClickListener(view -> {
            try {
                startActivity(new Intent("android.settings.VPN_SETTINGS"));
            } catch (Exception e) {
                status.setText("Nie można otworzyć ustawień VPN w tym telefonie.");
            }
        });
        root.addView(vpn);

        TextView info = Style.label(this,
                "W domu: użyj własnego Wi-Fi. Poza domem: aktywuj uprzednio skonfigurowany " +
                "VPN do sieci domowej; aplikacja skorzysta z zapisanego adresu routera. " +
                "Sama nie tworzy połączenia VPN ani nie otwiera panelu na internet. " +
                "Auto-logowanie działa tylko z HTTP Basic Authentication.", 13, false);
        info.setTextColor(Style.MUTED);
        root.addView(info);
        setContentView(scroll);
        refreshAddress();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (addressStatus != null) refreshAddress();
    }

    private void refreshAddress() {
        String saved = RouterAddressStore.read(this);
        String detected = WifiGatewayDiscovery.detect(this);
        AddressChoice choice = AddressChoice.choose(saved, detected);
        currentRouterIp = choice.ip;
        selectedSource = choice.source;
        if (choice.wifiDifferentFromSaved) {
            addressStatus.setText("Zapisany ASUS: " + saved + ". Bieżąca brama Wi-Fi: " + detected +
                    ". Adres może pochodzić z obcej sieci — nie zmieniam zapisu automatycznie.");
        } else if (choice.source == AddressChoice.Source.SAVED) {
            addressStatus.setText("Zapisany adres routera: " + choice.ip +
                    (detected != null ? " (zgodny z bramą Wi-Fi)." : " (brak lokalnego wykrywania; użyj VPN poza domem)."));
        } else if (choice.source == AddressChoice.Source.WIFI_GATEWAY) {
            addressStatus.setText("Wykryta brama Wi-Fi: " + choice.ip +
                    ". Potwierdź, że to Twój ASUS, przed wysłaniem loginu i hasła.");
        } else {
            addressStatus.setText("Nie wykryto bramy Wi-Fi. Proponowany adres: " + choice.ip +
                    ". Możesz wpisać go ręcznie.");
            manualPanel.setVisibility(View.VISIBLE);
        }
        if (manualPanel.getVisibility() == View.VISIBLE) addressInput.setText(currentRouterIp);
    }

    private void saveManualAddress() {
        String ip = addressInput.getText().toString().trim();
        if (!AddressPolicy.isPrivateIpv4(ip)) {
            addressInput.setError("Podaj prywatny adres IPv4, np. 192.168.2.1");
            status.setText("Niepoprawny adres routera. Nie podawaj domeny ani portu.");
            return;
        }
        try {
            RouterAddressStore.save(this, ip);
            refreshAddress();
            manualPanel.setVisibility(View.GONE);
            status.setText("Adres routera zapisany: " + ip + ". Hasło nie zostało zapisane.");
        } catch (RuntimeException exception) {
            status.setText("Nie udało się zapisać adresu. Sprawdź wpisane IP.");
        }
    }

    private void connect() {
        String login = loginInput.getText().toString().trim();
        Editable password = passwordInput.getText();
        if (login.isEmpty() || password == null || password.length() == 0) {
            status.setText("Wpisz login i hasło administratora routera.");
            return;
        }
        final String ip = currentRouterIp;
        if (!AddressPolicy.isPrivateIpv4(ip)) {
            status.setText("Najpierw zatwierdź poprawny adres routera.");
            manualPanel.setVisibility(View.VISIBLE);
            return;
        }
        if (!VpnPolicy.canAccessPanel(this, ip)) {
            status.setText("Brak drogi do adresu " + ip +
                    ". Połącz domowe Wi-Fi lub wcześniej skonfigurowany VPN. " +
                    "Jeśli adres jest inny, wybierz WPISZ ADRES ROUTERA RĘCZNIE.");
            manualPanel.setVisibility(View.VISIBLE);
            return;
        }

        // Same IP bramy nie potwierdza tozsamosci routera; ostroznosc przy HTTP.
        boolean firstTime = RouterAddressStore.read(this) == null;
        if (VpnPolicy.isWifiWithoutVpn(this) || firstTime) {
            new AlertDialog.Builder(this)
                    .setTitle("Potwierdź adres swojego ASUS-a")
                    .setMessage("Aplikacja użyje adresu " + ip +
                            ". Android rozpoznał trasę sieciową, ale nie może potwierdzić, " +
                            "że to Twój ASUS. Kontynuuj tylko we własnej domowej sieci Wi-Fi " +
                            "lub w zaufanym VPN. Logowanie po HTTP nie ma szyfrowania TLS.")
                    .setNegativeButton("ANULUJ", (dialog, which) -> { })
                    .setNeutralButton("ZMIEŃ IP", (dialog, which) -> manualPanel.setVisibility(View.VISIBLE))
                    .setPositiveButton("POTWIERDZAM", (dialog, which) -> {
                        try {
                            RouterAddressStore.save(this, ip);
                            startPanel(ip);
                        } catch (RuntimeException exception) {
                            status.setText("Nie udało się zapisać adresu routera.");
                        }
                    }).show();
        } else {
            startPanel(ip);
        }
    }

    private void startPanel(String ip) {
        if (!VpnPolicy.canAccessPanel(this, ip)) {
            status.setText("Połączenie sieciowe uległo zmianie. Spróbuj ponownie.");
            return;
        }
        Editable editable = passwordInput.getText();
        if (editable == null || editable.length() == 0) {
            status.setText("Hasło nie jest już dostępne. Wpisz je ponownie.");
            return;
        }
        char[] secret = new char[editable.length()];
        editable.getChars(0, editable.length(), secret, 0);
        String login = loginInput.getText().toString().trim();
        try {
            SessionCredentials.set(login, secret);
        } finally {
            Arrays.fill(secret, '\0');
            editable.clear();
            loginInput.getText().clear();
        }
        try {
            InputMethodManager input = (InputMethodManager)
                    getSystemService(Context.INPUT_METHOD_SERVICE);
            if (input != null) input.hideSoftInputFromWindow(passwordInput.getWindowToken(), 0);
            startActivity(new Intent(this, RouterPanelActivity.class)
                    .putExtra(RouterPanelActivity.EXTRA_ROUTER_IP, ip));
            status.setText("Otwieranie panelu routera " + ip + "…");
        } catch (RuntimeException exception) {
            SessionCredentials.clear();
            status.setText("Nie udało się otworzyć panelu routera.");
        }
    }
}
