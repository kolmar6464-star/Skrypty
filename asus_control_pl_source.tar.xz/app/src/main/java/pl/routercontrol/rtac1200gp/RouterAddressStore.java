package pl.routercontrol.rtac1200gp;

import android.content.Context;
import android.content.SharedPreferences;

/** Zapamietuje tylko adres IP routera. Nigdy login ani haslo. */
public final class RouterAddressStore {
    private static final String PREFS = "asus_control_router_settings";
    private static final String KEY_ADDRESS = "router_ipv4";

    private RouterAddressStore() { }

    public static String read(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String value = prefs.getString(KEY_ADDRESS, null);
        return AddressPolicy.isPrivateIpv4(value) ? value : null;
    }

    public static void save(Context context, String address) {
        if (!AddressPolicy.isPrivateIpv4(address)) {
            throw new IllegalArgumentException("Niepoprawny prywatny adres IPv4 routera.");
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY_ADDRESS, address).apply();
    }
}
