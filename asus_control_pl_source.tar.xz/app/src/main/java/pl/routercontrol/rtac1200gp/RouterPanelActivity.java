package pl.routercontrol.rtac1200gp;

import android.app.Activity;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.HttpAuthHandler;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.ByteArrayInputStream;

/** Panel uruchamia się wyłącznie przez zaufaną sieć LAN lub aktywny VPN. */
public final class RouterPanelActivity extends Activity {
    public static final String EXTRA_ROUTER_IP = "pl.routercontrol.rtac1200gp.ROUTER_IP";
    private String routerIp;
    private WebView webView;
    private ConnectivityManager cm;
    private ConnectivityManager.NetworkCallback callback;
    private TextView status;
    private boolean authenticationAttempted;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        getWindow().setStatusBarColor(Style.BG);
        getWindow().setNavigationBarColor(Style.BG);
        routerIp = getIntent().getStringExtra(EXTRA_ROUTER_IP);
        if (!AddressPolicy.isPrivateIpv4(routerIp) || !VpnPolicy.canAccessPanel(this, routerIp)) {
            SessionCredentials.clear();
            finish();
            return;
        }

        cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        LinearLayout root = Style.column(this);
        root.setBackgroundColor(Style.BG);
        root.setPadding(Style.dp(this, 12), Style.dp(this, 8),
                Style.dp(this, 12), Style.dp(this, 6));
        root.addView(Style.label(this, "ASUS RT-AC1200G+   •   " + routerIp, 15, true));

        status = Style.label(this, "Łączenie z routerem…", 13, false);
        status.setTextColor(Style.MUTED);
        root.addView(status);

        Button close = Style.button(this, "ZAMKNIJ I WYLOGUJ");
        close.setOnClickListener(view -> {
            clearSession();
            finish();
        });
        root.addView(close);

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true); // Panel ASUSWRT korzysta z JavaScript.
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        settings.setSaveFormData(false);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, false);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !allowed(request.getUrl());
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return !allowed(Uri.parse(url));
            }
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if (!allowed(request.getUrl()) ||
                        !VpnPolicy.canAccessPanel(RouterPanelActivity.this, routerIp)) {
                    return denied();
                }
                return null;
            }
            @Override
            public void onReceivedHttpAuthRequest(WebView view, HttpAuthHandler handler,
                                                  String host, String realm) {
                if (!routerIp.equals(host) ||
                        !VpnPolicy.canAccessPanel(RouterPanelActivity.this, routerIp)) {
                    handler.cancel();
                    status.setText("Zablokowano uwierzytelnienie spoza routera.");
                    return;
                }
                if (authenticationAttempted) {
                    handler.cancel();
                    status.setText("Router odrzucił login lub hasło. Zamknij panel i spróbuj ponownie.");
                    return;
                }
                SessionCredentials.Secret secret = SessionCredentials.consume();
                if (secret == null) {
                    handler.cancel();
                    status.setText("Brak danych logowania. Wróć do ekranu logowania.");
                    return;
                }
                authenticationAttempted = true;
                handler.proceed(secret.username, secret.password);
                status.setText("Weryfikacja danych logowania…");
            }
            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.cancel();
                status.setText("Błąd certyfikatu HTTPS. Nie pominięto zabezpieczeń.");
            }
            @Override
            public void onPageFinished(WebView view, String url) {
                if (!authenticationAttempted) {
                    status.setText("Panel został otwarty. Jeśli router używa formularza logowania, " +
                            "zaloguj się w panelu — ta wersja automatyzuje HTTP Basic Auth.");
                } else {
                    status.setText("Panel routera — logowanie zostało przekazane.");
                }
            }
        });
        root.addView(webView, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        if (cm != null) {
            callback = new ConnectivityManager.NetworkCallback() {
                @Override public void onCapabilitiesChanged(Network network,
                                                             NetworkCapabilities capabilities) {
                    enforceAccess();
                }
                @Override public void onLost(Network network) {
                    enforceAccess();
                }
            };
            cm.registerDefaultNetworkCallback(callback);
        }
        webView.loadUrl(AddressPolicy.buildUrl(routerIp, RouterDefaults.HTTP_PORT, false));
    }

    private void enforceAccess() {
        if (!VpnPolicy.canAccessPanel(this, routerIp)) {
            runOnUiThread(() -> {
                if (!isFinishing()) {
                    clearSession();
                    finish();
                }
            });
        }
    }

    private boolean allowed(Uri uri) {
        if (uri == null || uri.getScheme() == null) return false;
        String scheme = uri.getScheme();
        if ("data".equalsIgnoreCase(scheme) || "blob".equalsIgnoreCase(scheme)) return true;
        if (!"http".equalsIgnoreCase(scheme)) return false;
        int port = uri.getPort();
        return routerIp.equals(uri.getHost()) && (port < 0 || port == 80);
    }

    private static WebResourceResponse denied() {
        return new WebResourceResponse("text/plain", "UTF-8",
                new ByteArrayInputStream(new byte[0]));
    }

    private void clearSession() {
        SessionCredentials.clear();
        try {
            if (webView != null) {
                webView.stopLoading();
                webView.clearHistory();
                webView.clearHttpAuthUsernamePassword();
                webView.clearCache(true);
                webView.loadUrl("about:blank");
            }
            CookieManager.getInstance().removeAllCookies(null);
            CookieManager.getInstance().flush();
            WebStorage.getInstance().deleteAllData();
        } catch (Exception e) {
            // Best-effort cleanup; never leave screen running without approved route.
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!VpnPolicy.canAccessPanel(this, routerIp)) {
            clearSession();
            finish();
        }
    }

    @Override
    protected void onDestroy() {
        if (cm != null && callback != null) {
            try {
                cm.unregisterNetworkCallback(callback);
            } catch (IllegalArgumentException ignored) {
                // Callback already removed by Android.
            }
        }
        clearSession();
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
