package pl.routercontrol.rtac1200gp;

/** Pure Java: kolejnosc wyboru adresu i etykieta jego pochodzenia. */
public final class AddressChoice {
    public enum Source { SAVED, WIFI_GATEWAY, SUGGESTED_DEFAULT }

    public final String ip;
    public final Source source;
    public final boolean wifiDifferentFromSaved;

    private AddressChoice(String ip, Source source, boolean different) {
        this.ip = ip;
        this.source = source;
        this.wifiDifferentFromSaved = different;
    }

    public static AddressChoice choose(String saved, String detected) {
        boolean validSaved = AddressPolicy.isPrivateIpv4(saved);
        boolean validDetected = AddressPolicy.isPrivateIpv4(detected);
        if (validSaved) {
            return new AddressChoice(saved, Source.SAVED,
                    validDetected && !saved.equals(detected));
        }
        if (validDetected) {
            return new AddressChoice(detected, Source.WIFI_GATEWAY, false);
        }
        return new AddressChoice(RouterDefaults.IP, Source.SUGGESTED_DEFAULT, false);
    }
}
