package pl.routercontrol.rtac1200gp;

import java.util.Arrays;

/** Dane logowania wyłącznie w pamięci RAM procesu; nie są zapisywane na dysku. */
public final class SessionCredentials {
    private static String username;
    private static char[] password;

    private SessionCredentials() { }

    public static synchronized void set(String login, char[] secret) {
        clear();
        if (login == null || login.isEmpty() || secret == null || secret.length == 0) {
            throw new IllegalArgumentException("Wymagany login i hasło.");
        }
        username = login;
        password = Arrays.copyOf(secret, secret.length);
    }

    /** Jednorazowy odczyt dla wyzwania HTTP Basic Authentication. */
    public static synchronized Secret consume() {
        if (username == null || password == null) {
            return null;
        }
        Secret result = new Secret(username, new String(password));
        clear();
        return result;
    }

    public static synchronized void clear() {
        username = null;
        if (password != null) {
            Arrays.fill(password, '\0');
            password = null;
        }
    }

    public static final class Secret {
        public final String username;
        public final String password;
        private Secret(String username, String password) {
            this.username = username;
            this.password = password;
        }
    }
}
