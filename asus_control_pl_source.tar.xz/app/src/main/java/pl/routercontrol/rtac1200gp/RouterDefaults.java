package pl.routercontrol.rtac1200gp;

/** Centralna konfiguracja dla ASUS RT-AC1200G+ w sieci 192.168.2.0/24. */
public final class RouterDefaults {
    public static final String IP = "192.168.2.1";
    public static final String LAN_CIDR = "192.168.2.0/24";
    public static final int HTTP_PORT = 80;
    public static final String PREVIOUS_DEFAULT_IP = "192.168.1.1";

    private RouterDefaults() { }

    /** Migruje wyłącznie domyślny adres starej wersji aplikacji. */
    public static boolean shouldMigrateOldDefault(String savedIp) {
        return PREVIOUS_DEFAULT_IP.equals(savedIp);
    }
}
