package pl.routercontrol.rtac1200gp;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.LinkAddress;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.RouteInfo;
import android.os.Build;

import java.net.InetAddress;
import java.net.UnknownHostException;

/** Dostep tylko do adresu prywatnego przez lokalny Wi-Fi/LAN lub aktywny VPN. */
public final class VpnPolicy {
    private VpnPolicy() { }

    private static ConnectivityManager manager(Context context) {
        return (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
    }

    public static boolean isWifiWithoutVpn(Context context) {
        ConnectivityManager cm = manager(context);
        if (cm == null) return false;
        Network active = cm.getActiveNetwork();
        if (active == null) return false;
        NetworkCapabilities caps = cm.getNetworkCapabilities(active);
        return caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                && !caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN);
    }

    /** Wlasna brama albo recznie wpisany IP w bezposrednio podlaczonej podsieci Wi-Fi. */
    public static boolean isLocalWifiRoute(Context context, String ip) {
        if (!AddressPolicy.isPrivateIpv4(ip) || !isWifiWithoutVpn(context)) return false;
        ConnectivityManager cm = manager(context);
        Network active = cm.getActiveNetwork();
        LinkProperties links = cm.getLinkProperties(active);
        if (links == null) return false;
        try {
            InetAddress target = InetAddress.getByName(ip);
            for (LinkAddress address : links.getLinkAddresses()) {
                if (target.equals(address.getAddress())) return false; // Nie jest to telefon.
            }
            for (RouteInfo route : links.getRoutes()) {
                if (!route.matches(target)) continue;
                InetAddress gateway = route.getGateway();
                if (route.isDefaultRoute()) {
                    if (gateway != null && target.equals(gateway)) return true;
                } else if (gateway == null || gateway.isAnyLocalAddress()) {
                    return true; // Trasa bezposrednio podlaczonego segmentu LAN.
                }
            }
        } catch (UnknownHostException exception) {
            return false;
        }
        return false;
    }

    public static boolean canAccessPanel(Context context, String ip) {
        return isLocalWifiRoute(context, ip) || canReachViaVpn(context, ip);
    }

    public static boolean canReachViaVpn(Context context, String ip) {
        if (!AddressPolicy.isPrivateIpv4(ip)) return false;
        ConnectivityManager cm = manager(context);
        if (cm == null) return false;
        Network active = cm.getActiveNetwork();
        if (active == null) return false;
        NetworkCapabilities caps = cm.getNetworkCapabilities(active);
        if (caps == null || !caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) return false;
        LinkProperties links = cm.getLinkProperties(active);
        if (links == null) return false;
        try {
            InetAddress target = InetAddress.getByName(ip);
            for (RouteInfo route : links.getRoutes()) {
                if (route.matches(target) && (Build.VERSION.SDK_INT < 33
                        || route.getType() == RouteInfo.RTN_UNICAST)) {
                    return true;
                }
            }
        } catch (UnknownHostException exception) {
            return false;
        }
        return false;
    }
}
