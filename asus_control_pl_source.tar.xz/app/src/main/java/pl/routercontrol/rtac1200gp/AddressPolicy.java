package pl.routercontrol.rtac1200gp;

/**
 * Policy: only RFC 1918 IPv4 literal addresses; never domain names, loopback,
 * public, link-local, multicast, or IPv6. No DNS resolutions are performed.
 */
public final class AddressPolicy {
    private AddressPolicy() { }

    public static boolean isPrivateIpv4(String value) {
        if (value == null || value.isEmpty() || !value.equals(value.trim())) {
            return false;
        }
        String[] parts = value.split("\\.", -1);
        if (parts.length != 4) {
            return false;
        }
        int[] v = new int[4];
        for (int i = 0; i < 4; i++) {
            String p = parts[i];
            if (p.isEmpty() || p.length() > 3 || (p.length() > 1 && p.charAt(0) == '0')) {
                return false;
            }
            int n = 0;
            for (int j = 0; j < p.length(); j++) {
                char c = p.charAt(j);
                if (c < '0' || c > '9') {
                    return false;
                }
                n = n * 10 + c - '0';
            }
            if (n > 255) {
                return false;
            }
            v[i] = n;
        }
        return v[0] == 10 || (v[0] == 172 && v[1] >= 16 && v[1] <= 31)
            || (v[0] == 192 && v[1] == 168);
    }

    public static boolean isAllowedPort(int port) {
        return port == 80 || port == 443 || port == 8443;
    }

    public static String buildUrl(String ip, int port, boolean https) {
        if (!isPrivateIpv4(ip) || !isAllowedPort(port)) {
            throw new IllegalArgumentException("Niedozwolony adres routera.");
        }
        if (!https && port != 80) {
            throw new IllegalArgumentException("HTTP może używać tylko portu 80.");
        }
        if (https && port == 80) {
            throw new IllegalArgumentException("HTTPS nie może używać portu 80.");
        }
        return (https ? "https://" : "http://") + ip + ":" + port + "/";
    }
}
