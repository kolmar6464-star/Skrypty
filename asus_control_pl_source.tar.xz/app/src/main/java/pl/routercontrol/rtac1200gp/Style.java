package pl.routercontrol.rtac1200gp;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class Style {
    public static final int BG = Color.rgb(13, 16, 23);
    public static final int PANEL = Color.rgb(27, 31, 41);
    public static final int RED = Color.rgb(219, 54, 61);
    public static final int WHITE = Color.rgb(242, 243, 247);
    public static final int MUTED = Color.rgb(172, 182, 198);

    private Style() { }

    public static int dp(Context c, int n) {
        return Math.round(c.getResources().getDisplayMetrics().density * n);
    }

    public static GradientDrawable card(Context c) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(PANEL);
        bg.setCornerRadius(dp(c, 14));
        return bg;
    }

    public static LinearLayout column(Context c) {
        LinearLayout layout = new LinearLayout(c);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    public static TextView label(Context c, String s, int size, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(WHITE);
        if (bold) {
            t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        }
        t.setPadding(0, dp(c, 8), 0, dp(c, 8));
        return t;
    }

    public static Button button(Context c, String s) {
        Button b = new Button(c);
        b.setText(s);
        b.setTextAllCaps(false);
        b.setTextColor(WHITE);
        GradientDrawable g = new GradientDrawable();
        g.setColor(RED);
        g.setCornerRadius(dp(c, 10));
        b.setBackground(g);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(c, 48));
        p.setMargins(0, dp(c, 10), 0, dp(c, 2));
        b.setLayoutParams(p);
        return b;
    }

    public static EditText input(Context c, String hint, String value) {
        EditText e = new EditText(c);
        e.setSingleLine(true);
        e.setHint(hint);
        e.setText(value);
        e.setTextColor(WHITE);
        e.setHintTextColor(MUTED);
        e.setSelectAllOnFocus(true);
        e.setPadding(dp(c, 12), dp(c, 8), dp(c, 12), dp(c, 8));
        e.setBackground(card(c));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(c, 48));
        p.setMargins(0, dp(c, 4), 0, dp(c, 10));
        e.setLayoutParams(p);
        return e;
    }
}
